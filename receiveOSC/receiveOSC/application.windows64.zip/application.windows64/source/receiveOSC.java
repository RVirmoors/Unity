import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import oscP5.*; 
import netP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class receiveOSC extends PApplet {



  
OscP5 oscP5;
NetAddress myRemoteLocation;


public void setup() {
  
  frameRate(25);
  
  oscP5 = new OscP5(this, 8999);
  myRemoteLocation = new NetAddress("127.0.0.1",9000);
  
  fill(0);
  text("receive on port 8999\n     send to port 9000", 50, 100);
}


public void draw() {
}

/* incoming osc message are forwarded to the oscEvent method. */
public void oscEvent(OscMessage theOscMessage) {
  /* print the address pattern and the typetag of the received OscMessage */
  /*print("### received an osc message.");
  print(" addrpattern: "+theOscMessage.addrPattern());
  println(" typetag: "+theOscMessage.typetag());*/
  
  oscP5.send(theOscMessage, myRemoteLocation); 
}
  public void settings() {  size(200,200); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "receiveOSC" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
